//
//  AudioStreaming.h
//  AudioStreaming
//
//  Created by Dimitrios Chatzieleftheriou on 19/05/2020.
//  Copyright © 2020 Dimitrios Chatzieleftheriou. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AudioStreaming.
FOUNDATION_EXPORT double AudioStreamingVersionNumber;

//! Project version string for AudioStreaming.
FOUNDATION_EXPORT const unsigned char AudioStreamingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AudioStreaming/PublicHeader.h>
